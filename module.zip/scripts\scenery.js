import Scenery from './classes/Scenery.js';
import { log } from './helpers.js';

// Make Scenery available globally for debugging and compatibility
window.Scenery = Scenery;

Hooks.once('init', () => {
  // eslint-disable-next-line no-console
  log('Scenery | Init');
  // Use the new namespaced helper if available (Foundry VTT v13+), otherwise fall back
  // to the global for older releases to maintain backward-compatibility.
  const loadTemplatesFn = (foundry?.applications?.handlebars?.loadTemplates) || loadTemplates;
  loadTemplatesFn(['modules/scenery/templates/variation.hbs']);
});
Hooks.on('init', () => {
  game.settings.register('scenery', 'showVariationsLabel', {
    name: game.i18n.localize('SCENERY.SETTING_SHOW_VARIATIONS'),
    hint: game.i18n.localize('SCENERY.SETTING_SHOW_VARIATIONS_HINT'),
    scope: 'world',
    config: true,
    type: Boolean,
    default: true,
    requiresReload: true,
  });
});

Hooks.on('getSceneDirectoryEntryContext', Scenery._onContextMenu);
Hooks.on('getSceneNavigationContext', Scenery._onContextMenu);
Hooks.on('canvasInit', Scenery._onCanvasInit);
Hooks.on('updateScene', Scenery._onUpdateScene);
Hooks.on('renderSceneDirectory', Scenery._onRenderSceneDirectory);
