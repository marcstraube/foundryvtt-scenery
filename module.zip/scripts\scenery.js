import Scenery from './classes/Scenery.js';
import { log } from './helpers.js';

console.log('Scenery | Module loading...');

// Make Scenery available globally for debugging and compatibility
window.Scenery = Scenery;

Hooks.once('init', () => {
  // eslint-disable-next-line no-console
  log('Scenery | Init');
  // Use the new namespaced helper if available (Foundry VTT v13+), otherwise fall back
  // to the global for older releases to maintain backward-compatibility.
  const loadTemplatesFn = (foundry?.applications?.handlebars?.loadTemplates) || loadTemplates;
  loadTemplatesFn(['modules/scenery/templates/variation.hbs']);
  
  // Register settings during init
  game.settings.register('scenery', 'showVariationsLabel', {
    name: game.i18n.localize('SCENERY.SETTING_SHOW_VARIATIONS'),
    hint: game.i18n.localize('SCENERY.SETTING_SHOW_VARIATIONS_HINT'),
    scope: 'world',
    config: true,
    type: Boolean,
    default: true,
    requiresReload: true,
  });
});

// Register context menu hooks immediately - they should work fine at module load time
console.log('Scenery | Registering context menu hooks...');
Hooks.on('getSceneDirectoryEntryContext', Scenery._onContextMenu);
Hooks.on('getSceneNavigationContext', Scenery._onContextMenu);
console.log('Scenery | Context menu hooks registered');

// Add a fallback button in case context menu fails
Hooks.on('renderSceneDirectory', (app, html, data) => {
  console.log('Scenery | Adding fallback button to Scene Directory');
  
  // Add a button to the directory header if we're a GM
  if (game.user.isGM) {
    const headerActions = html.find('.directory-header .header-actions');
    if (headerActions.length && !headerActions.find('.scenery-button').length) {
      const sceneryButton = $(`<button class="scenery-button" title="${game.i18n.localize('SCENERY.APP_NAME')}">
        <i class="fas fa-images"></i>
      </button>`);
      
      sceneryButton.on('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        
        // Get the currently selected scene or the first scene
        const selectedScene = html.find('.directory-item.context').data('document-id') || 
                            game.scenes.contents[0]?.id;
        
        if (selectedScene) {
          console.log('Scenery | Opening from fallback button for scene:', selectedScene);
          new Scenery({ sceneId: selectedScene }).render(true);
        } else {
          ui.notifications.warn("Please select a scene first");
        }
      });
      
      headerActions.prepend(sceneryButton);
    }
  }
});

// Test if hooks are actually being stored
setTimeout(() => {
  console.log('Scenery | Checking hook registration:', {
    hasHooksObject: typeof Hooks !== 'undefined',
    directoryHook: Hooks.events?.getSceneDirectoryEntryContext?.length || 'Not found',
    navigationHook: Hooks.events?.getSceneNavigationContext?.length || 'Not found'
  });
}, 1000);

// Register other hooks after ready
Hooks.once('ready', () => {
  log('Scenery | Ready - Registering remaining hooks');
  
  Hooks.on('canvasInit', Scenery._onCanvasInit);
  Hooks.on('updateScene', Scenery._onUpdateScene);
  Hooks.on('renderSceneDirectory', Scenery._onRenderSceneDirectory);
  
  log('Scenery | All hooks registered successfully');
  
  // Debug: Check if hooks are actually registered
  console.log('Scenery | Context menu hooks exist:', {
    directory: typeof Hooks.events?.getSceneDirectoryEntryContext !== 'undefined',
    navigation: typeof Hooks.events?.getSceneNavigationContext !== 'undefined'
  });
});
