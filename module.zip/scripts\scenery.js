import Scenery from './classes/Scenery.js';
import { log } from './helpers.js';

console.log('Scenery | Module loading...');

// Make Scenery available globally for debugging and compatibility
window.Scenery = Scenery;

Hooks.once('init', () => {
  // eslint-disable-next-line no-console
  log('Scenery | Init');
  // Use the new namespaced helper if available (Foundry VTT v13+), otherwise fall back
  // to the global for older releases to maintain backward-compatibility.
  const loadTemplatesFn = (foundry?.applications?.handlebars?.loadTemplates) || loadTemplates;
  loadTemplatesFn(['modules/scenery/templates/variation.hbs']);
  
  // Register settings during init
  game.settings.register('scenery', 'showVariationsLabel', {
    name: game.i18n.localize('SCENERY.SETTING_SHOW_VARIATIONS'),
    hint: game.i18n.localize('SCENERY.SETTING_SHOW_VARIATIONS_HINT'),
    scope: 'world',
    config: true,
    type: Boolean,
    default: true,
    requiresReload: true,
  });
});

// Register context menu hooks immediately - they should work fine at module load time
console.log('Scenery | Registering context menu hooks...');
Hooks.on('getSceneDirectoryEntryContext', Scenery._onContextMenu);
Hooks.on('getSceneNavigationContext', Scenery._onContextMenu);
console.log('Scenery | Context menu hooks registered');

// Add a fallback button in case context menu fails
Hooks.on('renderSceneDirectory', (app, html, data) => {
  console.log('Scenery | Adding scenery button to Scene Directory');
  
  // Handle both jQuery objects and plain HTMLElements
  const htmlElement = html instanceof HTMLElement ? html : html[0];
  if (!htmlElement) return;
  
  // Add a button to the directory header if we're a GM
  if (game.user.isGM) {
    const headerActions = htmlElement.querySelector('.directory-header .header-actions');
    if (headerActions && !headerActions.querySelector('.scenery-button')) {
      const sceneryButton = document.createElement('button');
      sceneryButton.className = 'scenery-button';
      sceneryButton.title = game.i18n.localize('SCENERY.APP_NAME');
      sceneryButton.innerHTML = '<i class="fas fa-images"></i>';
      
      sceneryButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        
        // Try to get the currently viewed scene first
        const currentSceneId = canvas.scene?.id;
        
        // If no scene is currently viewed, get the selected one
        const selectedItem = htmlElement.querySelector('.directory-item.context') || 
                           htmlElement.querySelector('.directory-item.active');
        const selectedSceneId = selectedItem?.dataset.documentId;
        
        const sceneId = currentSceneId || selectedSceneId || game.scenes.contents[0]?.id;
        
        if (sceneId) {
          console.log('Scenery | Opening for scene:', sceneId);
          new Scenery({ sceneId }).render(true);
        } else {
          ui.notifications.warn("No scene available");
        }
      });
      
      // Insert the button after the create scene button
      const createButton = headerActions.querySelector('[data-action="create"]');
      if (createButton) {
        createButton.after(sceneryButton);
      } else {
        headerActions.prepend(sceneryButton);
      }
    }
  }
  
  // Also add context menu handler to individual scenes
  Scenery._onRenderSceneDirectory(app, html);
});

// Test if hooks are actually being stored
setTimeout(() => {
  console.log('Scenery | Checking hook registration:', {
    hasHooksObject: typeof Hooks !== 'undefined',
    directoryHook: Hooks.events?.getSceneDirectoryEntryContext?.length || 'Not found',
    navigationHook: Hooks.events?.getSceneNavigationContext?.length || 'Not found'
  });
}, 1000);

// Register other hooks after ready
Hooks.once('ready', () => {
  log('Scenery | Ready - Registering remaining hooks');
  
  Hooks.on('canvasInit', Scenery._onCanvasInit);
  Hooks.on('updateScene', Scenery._onUpdateScene);
  Hooks.on('renderSceneDirectory', Scenery._onRenderSceneDirectory);
  
  log('Scenery | All hooks registered successfully');
  
  // Debug: Check if hooks are actually registered
  console.log('Scenery | Context menu hooks exist:', {
    directory: typeof Hooks.events?.getSceneDirectoryEntryContext !== 'undefined',
    navigation: typeof Hooks.events?.getSceneNavigationContext !== 'undefined'
  });
});
