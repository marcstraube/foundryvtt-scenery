import { PATH } from '../helpers.js';

const { HandlebarsApplicationMixin, DocumentSheetV2 } = foundry.applications.api;

export default class Scenery extends HandlebarsApplicationMixin(DocumentSheetV2) {
  constructor(options = {}) {
    const sceneId = options.document?.id || options.sceneId;
    const scene = options.document || game.scenes.get(sceneId);
    super({ document: scene, ...options });
  }

  static DEFAULT_OPTIONS = {
    classes: ['scenery'],
    position: {
      width: 700,
      height: 'auto'
    },
    actions: {
      delete: Scenery.#onDelete,
      preview: Scenery.#onPreview,
      scan: Scenery.#onScan,
      add: Scenery.#onAdd
    },
    form: {
      handler: function(...args) { 
        return this._onFormSubmit(...args); 
      },
      submitOnChange: false,
      closeOnSubmit: true
    },
    window: {
      icon: 'fas fa-images',
      resizable: true,
      contentClasses: ["standard-form"]
    },
    tag: "form"
  };

  static PARTS = {
    form: {
      template: `${PATH}/templates/scenery.hbs`
    },
    footer: {
      template: "templates/generic/form-footer.hbs"
    }
  };

  get title() {
    return game.i18n.localize('SCENERY.APP_NAME');
  }

  /* -------------------------------------------- */

  /**
   * Prepare data for rendering
   * @returns {Promise<Object>}
   */
  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const flag = this.document.getFlag('scenery', 'data') || {};
    
    // Get the currently displayed background
    const currentBackground = this.getCurrentBackground();
    
    if (!this.bg) this.bg = flag.bg || currentBackground;
    if (!this.gm) this.gm = flag.gm || currentBackground;
    if (!this.pl) this.pl = flag.pl || currentBackground;
    if (!this.variations) {
      this.variations = [{ name: 'Default', file: this.bg }];
      if (flag.variations) {
        // Filter out any existing "Default" entries to avoid duplicates
        const nonDefaultVariations = flag.variations.filter(v => 
          v.name?.toLowerCase() !== 'default'
        );
        nonDefaultVariations.forEach((v) => this.variations.push(v));
      }
    }

    // Add extra empty variation
    this.variations.push({ name: '', file: '' });
    
    context.variations = this.variations;
    context.gm = this.gm;
    context.pl = this.pl;
    
    // Add buttons for the footer
    context.buttons = [
      { type: "button", action: "scan", icon: "fas fa-search", label: "SCENERY.BUTTON_SCAN" },
      { type: "button", action: "add", icon: "fa fa-plus", label: "SCENERY.BUTTON_ADD" },
      { type: "submit", icon: "fa fa-check", label: "SCENERY.BUTTON_OK" }
    ];
    
    return context;
  }

  /**
   * Get the currently displayed background based on user role
   * @returns {string} The current background image path
   */
  getCurrentBackground() {
    // If this scene is currently viewed on canvas
    if (canvas.scene?.id === this.document.id) {
      return canvas.scene.background.src;
    }
    
    // Otherwise check if there's custom scenery data
    const flag = this.document.getFlag('scenery', 'data');
    if (flag) {
      const customBg = game.user.isGM ? flag.gm : flag.pl;
      if (customBg) return customBg;
    }
    
    // Default to the scene's background
    return this.document.background.src;
  }

  /* -------------------------------------------- */
  /*  Event Listeners and Handlers                */
  /* -------------------------------------------- */

  /**
   * Handle delete button click
   * @param {PointerEvent} event
   * @param {HTMLElement} target
   */
  static async #onDelete(event, target) {
    const row = target.closest('tr');
    if (row) row.remove();
  }

  /**
   * Handle preview button click
   * @param {PointerEvent} event
   * @param {HTMLElement} target
   */
  static async #onPreview(event, target) {
    const row = target.closest('tr');
    const url = row?.querySelector('.image')?.value?.trim();
    if (url) {
      new ImagePopout(url).render(true);
    }
  }

  /**
   * Handle scan button click
   * @param {PointerEvent} event
   * @param {HTMLElement} target
   */
  static async #onScan(event, target) {
    const app = this;
    
    // Get path of default img
    const path = app.element.querySelector('[name="variations.0.file"]')?.value;
    if (!path) return;
    
    // Get paths of all current variant images
    const imagePaths = Array.from(app.element.querySelectorAll('input.image')).map(input => input.value);
    
    // Load list of files in current dir
    const fp = await foundry.applications.apps.FilePicker.implementation.browse('data', path);
    
    // Isolate file name and remove extension
    const defName = path.split('/').pop().split('.').slice(0, -1).join('.');
    
    // For each file in directory...
    const variations = fp.files
      // Remove already existing variant images
      .filter((f) => !imagePaths.includes(f))
      // Find only files which are derivatives of default
      .reduce((acc, file) => {
        // Isolate filename and remove extension
        const fn = file.split('/').pop().split('.').slice(0, -1).join('.');
        // If is a derivative...
        if (fn.toLowerCase().includes(defName.toLowerCase())) {
          // Remove crud from filename
          const name = decodeURIComponent(fn.replace(defName, ''))
            .replace(/[-_]/g, ' ')
            .replace(/\s{2,}/g, ' ')
            .trim();
          // Add to found array
          acc.push({ file, name });
        }
        return acc;
      }, [])
      .sort((a, b) => a.name.localeCompare(b.name));

    // Remove blank variations
    app.removeBlankVariations();
    
    // Add new variations
    for (const v of variations) {
      await app.addVariation(v.name, v.file);
    }
    
    // Add empty row at end
    await app.addVariation('', '');
  }

  /**
   * Handle add button click
   * @param {PointerEvent} event
   * @param {HTMLElement} target
   */
  static async #onAdd(event, target) {
    const app = this;
    await app.addVariation();
  }

  

  /**
   * Handle form submission
   * @param {Event} event
   * @param {HTMLFormElement} form
   * @param {FormDataExtended} formData
   * @param {Object} options - Additional submission options
   */
  async _onFormSubmit(event, form, formData, options = {}) {
    try {
      console.log('Scenery | Form submission started', { formData: formData.object, options });
      
      const fd = formData.object;
      
      // Parse the flat form data into nested variations array
      const variations = [];
      let index = 0;
      
      // Continue parsing variations until we don't find any more
      while (fd[`variations.${index}.file`] !== undefined) {
        variations.push({
          name: fd[`variations.${index}.name`] || '',
          file: fd[`variations.${index}.file`] || ''
        });
        index++;
      }
      
      console.log('Scenery | Parsed variations:', variations);
      
      // Get the background (first variation)
      const bg = variations[0]?.file;
      if (!bg) {
        ui.notifications.error('No default background specified');
        return;
      }
      
      // Get GM and PL selections from radio buttons
      const gmRadio = form.querySelector('input[name="gm"]:checked');
      const plRadio = form.querySelector('input[name="pl"]:checked');
      
      const gmIndex = parseInt(gmRadio?.value);
      const plIndex = parseInt(plRadio?.value);
      
      const gm = variations[gmIndex]?.file;
      const pl = variations[plIndex]?.file;
      
      if (!gm || !pl) {
        ui.notifications.error(game.i18n.localize('SCENERY.ERROR_SELECTION'));
        return;
      }
      
      // Filter out empty variations (except the first one which is the default)
      const validVariations = variations.slice(1).filter((v) => v.file);
      
      const data = { variations: validVariations, bg, gm, pl };
      
      console.log('Scenery | Saving data:', data);
      
      // Only update the scenery flag data
      await this.document.setFlag('scenery', 'data', data);
      
      // If this is the currently viewed scene, update the background immediately
      if (this.document.id === canvas.scene?.id) {
        const img = game.user.isGM ? gm : pl;
        if (img) {
          console.log('Scenery | Updating background directly from form submission');
          await Scenery.setImage(img);
        }
      }
      
      console.log('Scenery | Form submission completed successfully');
    } catch (error) {
      console.error('Scenery | Error in form submission:', error);
      ui.notifications.error(`Scenery error: ${error.message}`);
      throw error; // Re-throw to let DocumentSheetV2 handle it
    }
  }

  /**
   * Called when the application is rendered
   * @param {Object} context - The render context
   * @param {Object} options - Render options
   */
  _onRender(context, options) {
    super._onRender(context, options);
    
    // Activate file pickers for v12/v13 compatibility
    this.element.querySelectorAll('button.file-picker').forEach(button => {
      button.addEventListener('click', this._onClickFilePicker.bind(this));
    });
  }

  /**
   * Handle file picker button clicks
   * @param {PointerEvent} event - The click event
   */
  async _onClickFilePicker(event) {
    event.preventDefault();
    const button = event.currentTarget;
    const input = button.parentElement.querySelector('input[type="text"]');
    
    if (!input) return;
    
    const fp = new foundry.applications.apps.FilePicker.implementation({
      type: button.dataset.type || 'imagevideo',
      current: input.value,
      callback: path => {
        input.value = path;
        // Trigger change event so the form knows the value changed
        input.dispatchEvent(new Event('change', {bubbles: true}));
      }
    });
    
    return fp.browse();
  }

  /* -------------------------------------------- */
  /*  Helper Methods                              */
  /* -------------------------------------------- */

  /**
   * Remove rows with empty file and name
   */
  removeBlankVariations() {
    const rows = this.element.querySelectorAll('tr');
    rows.forEach((row) => {
      const fileInput = row.querySelector('.scenery-fp input');
      const nameInput = row.querySelector('.scenery-name input');
      if (fileInput && nameInput && !fileInput.value && !nameInput.value) {
        row.remove();
      }
    });
  }

  /**
   * Add a new variation row
   * @param {string} name
   * @param {string} file
   * @param {number|null} id
   */
  async addVariation(name = '', file = '', id = null) {
    const tbody = this.element.querySelector('.scenery-table');
    if (!tbody) return;
    
    if (id === null) {
      const lastRow = tbody.querySelector('tr:last-child');
      const lastIndex = lastRow ? parseInt(lastRow.getAttribute('data-index')) : -1;
      id = lastIndex + 1;
    }
    
    const rowHtml = await foundry.applications.handlebars.renderTemplate(`${PATH}/templates/variation.hbs`, { id, name, file });
    const template = document.createElement('template');
    template.innerHTML = rowHtml;
    const row = template.content.firstElementChild;
    
    tbody.appendChild(row);
    
    // Activate file picker for the newly added row (v12/v13 compatibility)
    const filePickerButton = row.querySelector('button.file-picker');
    if (filePickerButton) {
      filePickerButton.addEventListener('click', this._onClickFilePicker.bind(this));
    }
  }

  /**
   * Sets background image of the current scene
   * @param {String} img   The image URL to be used
   * @param {Boolean} draw Used to prevent draw if being called during canvasInit
   */
  static async setImage(img, draw = true) {
    if (!canvas.scene) return;
    
    // Store the custom background path in a non-persistent way
    const previousCustomBg = canvas.scene._sceneryCustomBackground;
    canvas.scene._sceneryCustomBackground = img;
    
    if (!draw) {
      // During canvas init, store the values we want to apply
      // Only store original if not already stored
      if (!canvas.scene._sceneryOriginalBackground) {
        canvas.scene._sceneryOriginalBackground = canvas.scene.background.src;
      }
      canvas.scene._sceneryPendingBackground = img;
      return;
    }
    
    // Check if the background is already set to this image
    if (canvas.scene.background.src === img) {
      console.log('Scenery | Background already set to:', img);
      return;
    }
    
    if (canvas.ready && canvas.primary?.background) {
      // Store the original source if not already stored
      if (!canvas.scene._sceneryOriginalBackground) {
        canvas.scene._sceneryOriginalBackground = canvas.scene.background.src;
      }
      
      try {
        console.log('Scenery | Loading new background texture:', img);
        
        // Load the new texture
        const texture = await foundry.canvas.loadTexture(img);
        
        if (texture && canvas.primary.background) {
          // Update the background mesh texture directly
          canvas.primary.background.texture = texture;
          
          // Update the scene data to reflect the change (without persisting)
          canvas.scene.background.src = img;
          
          // Force a re-render of the primary canvas group
          canvas.primary.renderDirty = true;
          canvas.app.renderer.render(canvas.app.stage);
          
          ui.notifications.info(game.i18n.localize('SCENERY.LOADING'));
        }
      } catch (err) {
        console.error('Scenery | Error updating background:', err);
        ui.notifications.error('Failed to update background image');
      }
    }
  }

  /**
   * Reset the background to its original source
   */
  static async resetBackground() {
    if (!canvas.scene || !canvas.scene._sceneryOriginalBackground) return;
    
    const originalSrc = canvas.scene._sceneryOriginalBackground;
    
    // Check if already reset
    if (canvas.scene.background.src === originalSrc) {
      console.log('Scenery | Background already reset to original');
      return;
    }
    
    if (canvas.primary?.background) {
      try {
        console.log('Scenery | Resetting background to original:', originalSrc);
        
        // Load the original texture
        const texture = await foundry.canvas.loadTexture(originalSrc);
        
        if (texture) {
          // Update the background mesh texture
          canvas.primary.background.texture = texture;
          
          // Update the scene data
          canvas.scene.background.src = originalSrc;
          
          // Force a re-render
          canvas.primary.renderDirty = true;
          canvas.app.renderer.render(canvas.app.stage);
        }
      } catch (err) {
        console.error('Scenery | Error resetting background:', err);
      }
    }
    
    delete canvas.scene._sceneryOriginalBackground;
    delete canvas.scene._sceneryCustomBackground;
  }

  /**
   * React to canvasInit hook to set custom image if needed
   */
  static _onCanvasInit() {
    const data = canvas.scene.getFlag('scenery', 'data');
    if (!data) return;
    
    // Check if the current background matches what we expect
    const currentBackground = canvas.scene.background.src;
    const expectedBackground = data.bg;
    
    // If the background doesn't match our stored base background, it may have been changed
    // through scene settings. Skip applying custom background to avoid overriding the change.
    if (currentBackground !== expectedBackground && !canvas.scene._sceneryPendingBackground) {
      console.log('Scenery | Background mismatch detected, skipping scenery override:', {
        current: currentBackground,
        expected: expectedBackground
      });
      return;
    }
    
    const img = (game.user.isGM) ? data.gm : data.pl;
    if (img) {
      // During canvas init, we just store what we want to apply
      // The actual application will happen after canvas is ready
      Scenery.setImage(img, false);
    }
  }

  /**
   * React to canvasReady hook to apply pending background changes
   */
  static async _onCanvasReady() {
    // Check if we have a pending background to apply
    if (canvas.scene?._sceneryPendingBackground) {
      const pendingImg = canvas.scene._sceneryPendingBackground;
      delete canvas.scene._sceneryPendingBackground;
      
      console.log('Scenery | Applying pending background:', pendingImg);
      
      // Use setImage to apply the pending background
      await Scenery.setImage(pendingImg);
    }
  }

  /**
   * React to updateScene hook to set custom image if needed
   * @param {Scene} scene
   * @param {Object} data
   */
  static _onUpdateScene(scene, data) {
    console.log('Scenery | _onUpdateScene called:', {
      sceneId: scene.id,
      isCurrentScene: scene.id === canvas.scene?.id,
      updateData: data,
      hasSceneryFlag: foundry.utils.hasProperty(data, 'flags.scenery.data'),
      hasBackgroundChange: foundry.utils.hasProperty(data, 'background.src')
    });
    
    ui.scenes.render();
    
    // Check if the background was changed through scene configuration
    if (foundry.utils.hasProperty(data, 'background.src')) {
      const newBackground = data.background.src;
      const sceneryData = scene.getFlag('scenery', 'data');
      
      if (sceneryData) {
        console.log('Scenery | Background changed through scene settings, updating scenery data');
        
        // Update the scenery data to use the new background as the base
        const updatedData = {
          ...sceneryData,
          bg: newBackground,
          // Reset GM and Player backgrounds to the new background if they were using the old one
          gm: sceneryData.gm === sceneryData.bg ? newBackground : sceneryData.gm,
          pl: sceneryData.pl === sceneryData.bg ? newBackground : sceneryData.pl
        };
        
        // Update the variations array to use the new background as default
        if (updatedData.variations && updatedData.variations.length > 0) {
          updatedData.variations[0] = { name: 'Default', file: newBackground };
        }
        
        // Update the flag with the new data
        scene.setFlag('scenery', 'data', updatedData);
        
        // If this is the current scene, update immediately
        if (scene.id === canvas.scene?.id) {
          const img = game.user.isGM ? updatedData.gm : updatedData.pl;
          if (img) {
            Scenery.setImage(img);
          }
        }
        
        return; // Exit early since we've handled the background change
      }
    }
    
    // Only update if this is the currently viewed scene and scenery data changed
    if (scene.id !== canvas.scene?.id) return;
    
    if (foundry.utils.hasProperty(data, 'flags.scenery.data')) {
      const img = (game.user.isGM) ? data.flags.scenery.data.gm : data.flags.scenery.data.pl;
      console.log('Scenery | Scenery data updated via hook, checking if update needed:', {
        newImg: img,
        currentBg: canvas.scene.background.src,
        customBg: canvas.scene._sceneryCustomBackground
      });
      
      if (img) {
        // setImage will check if the background is already correct
        console.log('Scenery | Calling setImage from update hook');
        Scenery.setImage(img);
      }
    }
  }

  /**
   * React to renderSceneDirectory to add count of Scenery variations on SceneDirectory entries.
   * @param {SceneDirectory} sceneDir
   * @param {Object} html
   * @private
   */
  static _onRenderSceneDirectory(sceneDir, html) {
    if (!game.settings.get('scenery', 'showVariationsLabel')) return;
    
    // Handle different types of html parameter (jQuery, HTMLElement, or array)
    const htmlElement = html instanceof jQuery ? html[0] : 
                       html instanceof HTMLElement ? html : 
                       Array.isArray(html) ? html[0] : 
                       html?.[0];
    
    if (!htmlElement) {
      console.warn('Scenery | _onRenderSceneDirectory: Invalid html parameter', html);
      return;
    }
    
    // Use game.scenes instead of sceneDir.documents
    const scenes = game.scenes?.contents || [];
    
    scenes
      .filter((scene) => scene?.flags?.scenery?.data?.variations?.length > 0)
      .forEach((scene) => {
        const menuEntry = htmlElement.querySelector(`[data-document-id="${scene.id}"]`);
        if (!menuEntry) return;
        
        const label = document.createElement('label');
        label.classList.add('scenery-variations');
        label.innerHTML = `<i class="fa fa-images"></i> ${scene.flags.scenery.data.variations.length + 1}`;
        menuEntry.prepend(label);
      });
  }

  /**
   * React to getSceneNavigationContext and getSceneDirectoryEntryContext hooks to add Scenery menu entry
   * @param {Object} html
   * @param {Object} entryOptions
   * @private
   */
  static _onContextMenu(html, entryOptions) {
    console.log('Scenery | _onContextMenu called', { html, entryOptions });
    
    const viewOption = {
      name: game.i18n.localize('SCENERY.APP_NAME'),
      icon: 'fas fa-images',
      condition: () => game.user.isGM,
      callback: li => {
        // Handle both jQuery objects and plain DOM elements
        const element = li.jquery ? li[0] : li;
        const id = element?.dataset?.documentId || element?.dataset?.sceneId;
        
        if (!id) {
          console.error('Scenery | No scene ID found on element', li);
          return;
        }
        
        console.log('Scenery | Opening for scene:', id);
        new Scenery({ sceneId: id }).render(true);
      }
    };
    entryOptions.push(viewOption);
    console.log('Scenery | Context menu option added', viewOption);
  }
}
